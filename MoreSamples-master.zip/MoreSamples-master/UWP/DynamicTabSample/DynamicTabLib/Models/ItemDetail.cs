﻿namespace DynamicTabLib.Models
{
    public class ItemDetail
    {
        public string ItemDetailId { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
