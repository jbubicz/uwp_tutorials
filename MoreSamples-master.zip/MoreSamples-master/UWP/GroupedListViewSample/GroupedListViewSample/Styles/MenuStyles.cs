﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupedListViewSample.Styles
{
    public partial class MenuStyles
    {
        public MenuStyles()
        {
            InitializeComponent();
        }
    }
}
