# Using .NET Core Libraries from UWP

This article descibes the SimpleMVVM sample with UWP: [Using .NET Core Libraries from UWP](https://csharp.christiannagel.com/2016/05/23/netcore-uwp/ ".NET Core from UWP")
