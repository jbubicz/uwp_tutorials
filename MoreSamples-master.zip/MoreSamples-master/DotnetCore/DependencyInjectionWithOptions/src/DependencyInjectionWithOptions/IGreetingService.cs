﻿namespace DependencyInjectionWithOptions
{
    public interface IGreetingService
    {
        string Greeting(string name);
    }
}
