# Dependency Injection with .NET Core

This article describes the dependency injection sample code: [Dependency Injection with .NET Core](https://csharp.christiannagel.com/2016/06/04/dependencyinjection/ "Dependency Injection")
