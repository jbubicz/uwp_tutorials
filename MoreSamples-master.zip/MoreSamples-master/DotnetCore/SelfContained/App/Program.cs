﻿using System;
using ClassLibrary;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main()
        {
            var sample = new Sample();
            sample.Foo();
        }
    }
}
