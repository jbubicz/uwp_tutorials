﻿namespace InheritanceSample
{
    public class CashPayment : Payment
    {
    }
}
