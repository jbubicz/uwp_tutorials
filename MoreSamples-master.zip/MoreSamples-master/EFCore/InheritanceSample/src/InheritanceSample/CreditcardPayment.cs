﻿namespace InheritanceSample
{
    public class CreditcardPayment : Payment
    {
        public string CreditcardNumber { get; set; }
    }
}
